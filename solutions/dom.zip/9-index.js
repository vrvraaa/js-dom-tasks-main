import app from './9-events-in-action.js';

app();
