import extractData from './5-search.js';

const data = extractData(document);
console.log(data);