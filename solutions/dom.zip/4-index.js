import extractData from './4-dom-hierarchy.js';

const data = extractData(document.documentElement);
console.log(data);